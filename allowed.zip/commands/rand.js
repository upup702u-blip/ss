const { joinVoiceChannel, getVoiceConnection } = require('@discordjs/voice');
const allowedUsers = require("../allowed.json").allowed;

const targetChannelId = '1284204173772062815'; // Channel to send bot messages

module.exports = {
    names: {
        list: ["rand", "rands"]
    },
    run: async (client, message, args) => {
        try {
            const targetChannel = client.channels.cache.get(targetChannelId); // Fetch target channel

            // Permission check
            if (!allowedUsers.includes(message.author.id)) {
                targetChannel.send("You don't have permission to use this command.");
                return;
            }

            // Handle stop command
            if (message.content.startsWith('vcstop')) {
                const connection = getVoiceConnection(message.guild.id);
                if (connection) {
                    connection.destroy(); // Disconnect from voice channel
                    targetChannel.send(`Bot stopped and disconnected from the voice channel.`);
                    stopLoop = true; // Set stop loop flag
                } else {
                    targetChannel.send("Bot is not connected to any voice channel.");
                }
                return; // Exit the function
            }

            // Proceed with normal vc join process
            if (args.length < 1) {
                targetChannel.send("Please provide a voice channel ID.");
                return;
            }

            const channelId = args[0];
            const channel = client.channels.cache.get(channelId);

            if (!channel || channel.type !== 'GUILD_VOICE') {
                targetChannel.send("Please provide a valid voice channel ID.");
                return;
            }

            let stopLoop = false; // Track whether to stop the loop

            const joinAndLeaveVC = async () => {
                if (stopLoop) return; // Stop if flag is set

                // Randomly set selfMute and selfDeaf
                const selfMute = Math.random() < 0.5; // 50% chance for true or false
                const selfDeaf = Math.random() < 0.2; // 50% chance for true or false

                // Join the voice channel
                const connection = joinVoiceChannel({
                    channelId: channel.id,
                    guildId: channel.guild.id,
                    adapterCreator: channel.guild.voiceAdapterCreator,
                    selfDeaf: selfDeaf,
                    selfMute: selfMute
                });

                targetChannel.send(`Joined voice channel: ${channel.name} with selfMute: ${selfMute} and selfDeaf: ${selfDeaf}`);

                // Stay connected for 10 minutes
                setTimeout(async () => {
                    const connection = getVoiceConnection(channel.guild.id);
                    if (connection) {
                        connection.destroy(); // Disconnect from the voice channel
                        targetChannel.send(`Disconnected from voice channel: ${channel.name}`);
                    }
                },  120 * 10 * 1000); // 10 minutes in milliseconds

                // Reconnect after 30 seconds
                setTimeout(joinAndLeaveVC, (60 * 1000) + (30 * 1000)); // Wait 10 min + 30 sec before reconnecting
            };

            joinAndLeaveVC();

        } catch (error) {
            console.error("Error occurred during the event:", error);
            const targetChannel = client.channels.cache.get(targetChannelId);
            targetChannel.send("An error occurred while trying to join the voice channel.");
        }
    }
};
